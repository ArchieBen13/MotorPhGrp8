package motorph;

import java.util.Scanner;

public class MotorPh {
    
    public static void main(String[] args) {
        //Scanner objectName = new Scanner(System.in)
        //shortcut key for import is alt + shift + i
        Scanner inp = new Scanner (System.in);
        //dataType variableName = value;
       int num;
       System.out.print("Enter a Employee Code:");
       //variableName = objectName.typeOfInput();
       num = inp.nextInt();
       System.out.println("Archie Benig");
      
    }
    
}
