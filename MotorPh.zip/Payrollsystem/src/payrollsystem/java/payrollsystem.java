package payrollsystem.java;

import java.util.Scanner;

public class payrollsystem {
    
    public static void main(String [] args) {
        Scanner inp = new Scanner (System.in);
        long empNum;
        String empName;
        double hoursSalary, weeklyTime, weeklySalary, overTime;
        double regPay, overtimePay, netPay;
        System.out.printf("Enter Employee No.:");
        empNum = inp.nextLong();
        System.out.printf("Enter hourly Salary:");
        hoursSalary = inp.nextDouble();
        System.out.println("Enter Weekly Time:");
        weeklyTime = inp.nextDouble ();
        
        if (empNum == 10001) {
            empName = "Archie Benig";
        }
        else if (empNum == 10002) {
            empName = "Diana Banas";
        }
        else if (empNum == 10003) {
            empName = "Samuel Chua";
        }
        else{
            empName = "Unknown Employee";  
            
        }
        if (weeklyTime < 100) {
        weeklySalary = weeklyTime;
        overTime = 0;
        regPay = hoursSalary * weeklyTime;
        overtimePay = 0; 
        netPay = regPay;
        }
        else{
        weeklySalary = 200;
        overTime = weeklyTime = 40;
        regPay = hoursSalary * weeklyTime;
        overtimePay = hoursSalary * overTime;
        netPay = regPay + overtimePay; 
        }
        
        System.out.println("-------------------");
        System.out.println("---PAYROLL SYSTEM---");
        System.out.println("-------------------");
        System.out.printf("Employee Number : %d\n", empNum);
        System.out.println("Employee Name : " + empName);
        System.out.println("Hourly Salary : " + hoursSalary);
        System.out.println("Weekly time : " + regPay);
        System.out.println("Overtime Pay : " + overtimePay);
        System.out.println("Net Pay : " + netPay);
}
}
 